#include <string.h>
#include <moulitest.h>
#include <mt.h>
#include <test.h>

PROTOTYPES

int main()
{
	t_mt	*mt = mt_create("sample test");

	ADD_TESTS

	mt_exec(mt);
	return(0);
}
