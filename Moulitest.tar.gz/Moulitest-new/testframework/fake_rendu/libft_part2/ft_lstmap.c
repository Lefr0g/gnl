#include <libft.h>
t_list	*ft_lstmap(t_list *lst, t_list *(*f)(t_list *elem))
{
	(void)lst;
	(void)f;
	return (NULL);
}
