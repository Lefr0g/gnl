#include <libft.h>
void	*ft_memcpy(void *dst, const void *src, size_t n)
{
	(void)src;
	(void)n;
	return (dst);
}
