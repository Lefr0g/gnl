#include <libft.h>
int	ft_toupper(int c)
{
	return (c);
}
