#include <libft.h>
void	ft_striter(char *s, void (*f)(char *))
{
	(void)s;
	(void)f;
}
