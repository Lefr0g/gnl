#include <libft.h>
int		ft_strcmp(const char *s1, const char *s2)
{
	(void)s1;
	(void)s2;
	return (0);
}
