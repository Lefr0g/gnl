#include <libft.h>
int		ft_strncmp(const char *s1, const char *s2, size_t n)
{
	(void)s1;
	(void)s2;
	(void)n;
	return (0);
}
